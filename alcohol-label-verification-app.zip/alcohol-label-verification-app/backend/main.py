import time
from typing import List
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware

from ocr_service import extract_text_from_image
from verifier import verify_label


app = FastAPI(
    title="AI-Powered Alcohol Label Verification API",
    description="Prototype API for OCR-based alcohol label verification.",
    version="1.0.0"
)

# For local prototype development.
# In production, restrict origins to the deployed frontend URL.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def health_check():
    return {
        "status": "ok",
        "message": "Alcohol Label Verification API is running."
    }


@app.post("/analyze")
async def analyze_labels(
    brand_name: str = Form(...),
    class_type: str = Form(...),
    alcohol_content: str = Form(...),
    net_contents: str = Form(...),
    files: List[UploadFile] = File(...)
):
    """
    Analyze one or more uploaded label images.
    """
    application_data = {
        "brand_name": brand_name,
        "class_type": class_type,
        "alcohol_content": alcohol_content,
        "net_contents": net_contents
    }

    batch_results = []

    for uploaded_file in files:
        start = time.perf_counter()

        file_bytes = await uploaded_file.read()

        try:
            extracted_text = extract_text_from_image(file_bytes)
            verification = verify_label(application_data, extracted_text)

            elapsed_ms = round((time.perf_counter() - start) * 1000, 2)

            batch_results.append({
                "file_name": uploaded_file.filename,
                "processing_time_ms": elapsed_ms,
                **verification
            })

        except Exception as exc:
            elapsed_ms = round((time.perf_counter() - start) * 1000, 2)

            batch_results.append({
                "file_name": uploaded_file.filename,
                "processing_time_ms": elapsed_ms,
                "overall_status": "error",
                "fields": [],
                "ocr_text": "",
                "error": str(exc)
            })

    return {
        "count": len(batch_results),
        "results": batch_results
    }
