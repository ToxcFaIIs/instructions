import re
from rapidfuzz import fuzz


STANDARD_WARNING = (
    "GOVERNMENT WARNING: "
    "(1) According to the Surgeon General, women should not drink alcoholic beverages "
    "during pregnancy because of the risk of birth defects. "
    "(2) Consumption of alcoholic beverages impairs your ability to drive a car or "
    "operate machinery, and may cause health problems."
)


def normalize_text(value: str) -> str:
    """
    Normalize text for forgiving comparison.
    """
    if not value:
        return ""

    value = value.lower()
    value = value.replace("’", "'")
    value = re.sub(r"[^a-z0-9%.' ]+", " ", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def normalize_strict(value: str) -> str:
    """
    Normalize text while preserving stricter wording comparison.
    """
    if not value:
        return ""

    value = value.replace("’", "'")
    value = re.sub(r"\s+", " ", value).strip()
    return value


def fuzzy_field_check(field_name: str, expected: str, label_text: str, pass_threshold=90, review_threshold=75):
    """
    General fuzzy comparison for text fields like brand name and class/type.
    """
    expected_norm = normalize_text(expected)
    label_norm = normalize_text(label_text)

    if not expected_norm:
        return {
            "field": field_name,
            "application_value": expected,
            "label_value": "",
            "status": "needs_review",
            "confidence": 0,
            "notes": "No application value provided."
        }

    if expected_norm in label_norm:
        return {
            "field": field_name,
            "application_value": expected,
            "label_value": expected,
            "status": "pass",
            "confidence": 100,
            "notes": "Expected value appears in label text."
        }

    score = fuzz.partial_ratio(expected_norm, label_norm)

    if score >= pass_threshold:
        status = "pass"
        notes = "Strong fuzzy match. Minor capitalization, spacing, or punctuation differences are likely acceptable."
    elif score >= review_threshold:
        status = "needs_review"
        notes = "Possible match, but agent review is recommended."
    else:
        status = "fail"
        notes = "Expected value was not found clearly on the label."

    return {
        "field": field_name,
        "application_value": expected,
        "label_value": "Detected in OCR text" if score >= review_threshold else "Not clearly detected",
        "status": status,
        "confidence": round(score, 2),
        "notes": notes
    }


def extract_abv_values(text: str):
    """
    Extract ABV percentages and proof values from OCR text.
    """
    text_norm = normalize_text(text)

    abv_matches = re.findall(r"(\d{1,3}(?:\.\d+)?)\s*%?\s*(?:alc|alcohol|abv|alc vol|alc./vol|alc vol.)", text_norm)
    percent_matches = re.findall(r"(\d{1,3}(?:\.\d+)?)\s*%", text_norm)
    proof_matches = re.findall(r"(\d{1,3}(?:\.\d+)?)\s*proof", text_norm)

    values = set()

    for match in abv_matches + percent_matches:
        try:
            values.add(round(float(match), 2))
        except ValueError:
            pass

    # In distilled spirits, proof is generally 2x ABV.
    for match in proof_matches:
        try:
            values.add(round(float(match) / 2, 2))
        except ValueError:
            pass

    return sorted(values)


def parse_expected_abv(expected: str):
    """
    Parse expected ABV from application value.
    """
    if not expected:
        return None

    expected_norm = normalize_text(expected)

    proof_match = re.search(r"(\d{1,3}(?:\.\d+)?)\s*proof", expected_norm)
    if proof_match:
        return round(float(proof_match.group(1)) / 2, 2)

    percent_match = re.search(r"(\d{1,3}(?:\.\d+)?)\s*%?", expected_norm)
    if percent_match:
        return round(float(percent_match.group(1)), 2)

    return None


def check_abv(expected: str, label_text: str):
    expected_abv = parse_expected_abv(expected)
    found_abvs = extract_abv_values(label_text)

    if expected_abv is None:
        return {
            "field": "Alcohol Content",
            "application_value": expected,
            "label_value": "",
            "status": "needs_review",
            "confidence": 0,
            "notes": "Could not parse expected alcohol content."
        }

    for found in found_abvs:
        if abs(found - expected_abv) <= 0.1:
            return {
                "field": "Alcohol Content",
                "application_value": expected,
                "label_value": f"{found}% ABV",
                "status": "pass",
                "confidence": 100,
                "notes": "Alcohol content matches. Proof values are converted to ABV when detected."
            }

    if found_abvs:
        return {
            "field": "Alcohol Content",
            "application_value": expected,
            "label_value": ", ".join([f"{v}% ABV" for v in found_abvs]),
            "status": "fail",
            "confidence": 40,
            "notes": "Alcohol content was detected, but it does not match the application value."
        }

    return {
        "field": "Alcohol Content",
        "application_value": expected,
        "label_value": "Not detected",
        "status": "fail",
        "confidence": 0,
        "notes": "Alcohol content was not detected in the OCR text."
    }


def normalize_volume_to_ml(value: str):
    """
    Normalize net contents to milliliters where possible.
    """
    if not value:
        return None

    value_norm = normalize_text(value)

    ml_match = re.search(r"(\d+(?:\.\d+)?)\s*m\s*l", value_norm)
    if ml_match:
        return round(float(ml_match.group(1)), 2)

    liter_match = re.search(r"(\d+(?:\.\d+)?)\s*l(?:iter|itre)?s?", value_norm)
    if liter_match:
        return round(float(liter_match.group(1)) * 1000, 2)

    return None


def extract_volumes_ml(text: str):
    text_norm = normalize_text(text)
    values = []

    ml_matches = re.findall(r"(\d+(?:\.\d+)?)\s*m\s*l", text_norm)
    liter_matches = re.findall(r"(\d+(?:\.\d+)?)\s*l(?:iter|itre)?s?", text_norm)

    for match in ml_matches:
        values.append(round(float(match), 2))

    for match in liter_matches:
        values.append(round(float(match) * 1000, 2))

    return sorted(set(values))


def check_net_contents(expected: str, label_text: str):
    expected_ml = normalize_volume_to_ml(expected)
    found_values = extract_volumes_ml(label_text)

    if expected_ml is None:
        return {
            "field": "Net Contents",
            "application_value": expected,
            "label_value": "",
            "status": "needs_review",
            "confidence": 0,
            "notes": "Could not parse expected net contents."
        }

    for found in found_values:
        if abs(found - expected_ml) <= 1:
            return {
                "field": "Net Contents",
                "application_value": expected,
                "label_value": f"{found:g} mL",
                "status": "pass",
                "confidence": 100,
                "notes": "Net contents match."
            }

    if found_values:
        return {
            "field": "Net Contents",
            "application_value": expected,
            "label_value": ", ".join([f"{v:g} mL" for v in found_values]),
            "status": "fail",
            "confidence": 40,
            "notes": "Net contents were detected, but they do not match the application value."
        }

    return {
        "field": "Net Contents",
        "application_value": expected,
        "label_value": "Not detected",
        "status": "fail",
        "confidence": 0,
        "notes": "Net contents were not detected in the OCR text."
    }


def check_government_warning(label_text: str):
    """
    Check the required government warning text.
    This prototype checks capitalization and wording, not visual boldness.
    """
    label_strict = normalize_strict(label_text)
    label_norm = normalize_text(label_text)
    warning_norm = normalize_text(STANDARD_WARNING)

    has_caps_header = "GOVERNMENT WARNING:" in label_strict
    wording_score = fuzz.partial_ratio(warning_norm, label_norm)

    if has_caps_header and wording_score >= 90:
        return {
            "field": "Government Warning",
            "application_value": "Required standard warning",
            "label_value": "Detected",
            "status": "pass",
            "confidence": round(wording_score, 2),
            "notes": "Required warning text and all-caps header detected. Boldness is not verified in this prototype."
        }

    if wording_score >= 75:
        return {
            "field": "Government Warning",
            "application_value": "Required standard warning",
            "label_value": "Possible warning detected",
            "status": "needs_review",
            "confidence": round(wording_score, 2),
            "notes": "Warning text appears close, but capitalization or wording may need agent review."
        }

    return {
        "field": "Government Warning",
        "application_value": "Required standard warning",
        "label_value": "Not clearly detected",
        "status": "fail",
        "confidence": round(wording_score, 2),
        "notes": "Required government warning was not clearly detected."
    }


def summarize_status(field_results):
    """
    Determine overall label result.
    """
    statuses = [item["status"] for item in field_results]

    if "fail" in statuses:
        return "fail"

    if "needs_review" in statuses:
        return "needs_review"

    return "pass"


def verify_label(application_data: dict, label_text: str):
    """
    Main verification function.
    """
    results = [
        fuzzy_field_check("Brand Name", application_data.get("brand_name", ""), label_text),
        fuzzy_field_check("Class/Type", application_data.get("class_type", ""), label_text),
        check_abv(application_data.get("alcohol_content", ""), label_text),
        check_net_contents(application_data.get("net_contents", ""), label_text),
        check_government_warning(label_text)
    ]

    return {
        "overall_status": summarize_status(results),
        "fields": results,
        "ocr_text": label_text
    }
