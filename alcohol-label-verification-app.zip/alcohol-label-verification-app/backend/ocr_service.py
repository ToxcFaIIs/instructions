import io
import cv2
import numpy as np
from PIL import Image
import easyocr

# EasyOCR loads the model once when the server starts.
# This improves speed after the first request.
reader = easyocr.Reader(["en"], gpu=False)


def preprocess_image(file_bytes: bytes) -> np.ndarray:
    """
    Convert uploaded image bytes into an OpenCV image and apply light preprocessing.
    """
    image = Image.open(io.BytesIO(file_bytes)).convert("RGB")
    image_np = np.array(image)

    # Convert RGB to BGR for OpenCV
    image_cv = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)

    # Grayscale and contrast enhancement for OCR
    gray = cv2.cvtColor(image_cv, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)

    return gray


def extract_text_from_image(file_bytes: bytes) -> str:
    """
    Extract text from an image using EasyOCR.
    """
    processed = preprocess_image(file_bytes)

    results = reader.readtext(processed, detail=0, paragraph=True)

    if not results:
        return ""

    return "\n".join(results)
