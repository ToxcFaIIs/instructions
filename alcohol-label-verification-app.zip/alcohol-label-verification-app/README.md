# AI-Powered Alcohol Label Verification App

A working prototype for verifying alcohol label artwork against application data.

This app is designed as a **human-in-the-loop compliance support tool**. It extracts text from label images using OCR, compares the extracted label text against submitted application fields, and flags matches, likely mismatches, and items requiring review.

## Features

- Upload one label image or multiple label images
- OCR text extraction from label artwork
- Brand name verification
- Class/type verification
- ABV and proof verification
- Net contents verification
- Government health warning verification
- Fuzzy matching for human-friendly comparisons
- Batch results table
- Processing time display
- No permanent file storage

## Tech Stack

### Backend
- Python
- FastAPI
- EasyOCR
- OpenCV
- RapidFuzz
- Pillow

### Frontend
- React
- Vite
- Tailwind CSS

## Project Structure

```text
alcohol-label-verification-app/
├── backend/
│   ├── main.py
│   ├── verifier.py
│   ├── ocr_service.py
│   └── requirements.txt
├── frontend/
│   ├── package.json
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── src/
│       ├── App.jsx
│       ├── main.jsx
│       └── index.css
└── README.md
```

## Backend Setup

```bash
cd backend
python -m venv venv
```

### Windows

```bash
venv\Scripts\activate
```

### macOS/Linux

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the backend:

```bash
uvicorn main:app --reload
```

The backend will run at:

```text
http://127.0.0.1:8000
```

## Frontend Setup

Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

The frontend will run at:

```text
http://localhost:5173
```

## How to Use

1. Open the frontend.
2. Enter application data:
   - Brand name
   - Class/type
   - Alcohol content
   - Net contents
3. Upload one or more label images.
4. Click **Analyze Label(s)**.
5. Review the field-by-field results.

## Assumptions

- This prototype does not integrate directly with COLA.
- Uploaded files are analyzed in memory and not permanently stored.
- The tool assists agents but does not make final legal compliance decisions.
- Bold detection for the government warning is listed as a future enhancement.
- The prototype focuses on common distilled spirits label checks.

## Known Limitations

- OCR accuracy depends on image quality.
- Glare, skew, low lighting, and distorted photos can reduce accuracy.
- The prototype checks government warning capitalization and wording, but not actual visual boldness.
- PDF support can be added later with `pdf2image`.

## Future Enhancements

- PDF label support
- Better rotated/skewed image correction
- Visual bounding boxes around detected text
- User authentication
- CSV export
- Direct COLA integration
- Azure Computer Vision or other FedRAMP-compatible OCR option
