import React, { useState } from "react";
import { Upload, AlertTriangle, CheckCircle, XCircle, Clock, FileText } from "lucide-react";

const API_URL = "http://127.0.0.1:8000";

function statusStyles(status) {
  switch (status) {
    case "pass":
      return "bg-green-100 text-green-800 border-green-300";
    case "needs_review":
      return "bg-yellow-100 text-yellow-800 border-yellow-300";
    case "fail":
      return "bg-red-100 text-red-800 border-red-300";
    case "error":
      return "bg-gray-100 text-gray-800 border-gray-300";
    default:
      return "bg-slate-100 text-slate-800 border-slate-300";
  }
}

function StatusIcon({ status }) {
  if (status === "pass") return <CheckCircle className="w-5 h-5" />;
  if (status === "fail") return <XCircle className="w-5 h-5" />;
  return <AlertTriangle className="w-5 h-5" />;
}

function prettyStatus(status) {
  if (status === "needs_review") return "Needs Review";
  if (!status) return "";
  return status.charAt(0).toUpperCase() + status.slice(1);
}

export default function App() {
  const [form, setForm] = useState({
    brand_name: "OLD TOM DISTILLERY",
    class_type: "Kentucky Straight Bourbon Whiskey",
    alcohol_content: "45%",
    net_contents: "750 mL"
  });

  const [files, setFiles] = useState([]);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function updateForm(event) {
    setForm({
      ...form,
      [event.target.name]: event.target.value
    });
  }

  function handleFileChange(event) {
    setFiles(Array.from(event.target.files));
  }

  async function analyzeLabels(event) {
    event.preventDefault();
    setLoading(true);
    setError("");
    setResults([]);

    if (files.length === 0) {
      setError("Please upload at least one label image.");
      setLoading(false);
      return;
    }

    const data = new FormData();
    data.append("brand_name", form.brand_name);
    data.append("class_type", form.class_type);
    data.append("alcohol_content", form.alcohol_content);
    data.append("net_contents", form.net_contents);

    files.forEach((file) => {
      data.append("files", file);
    });

    try {
      const response = await fetch(`${API_URL}/analyze`, {
        method: "POST",
        body: data
      });

      if (!response.ok) {
        throw new Error("The backend returned an error.");
      }

      const payload = await response.json();
      setResults(payload.results || []);
    } catch (err) {
      setError(
        "Unable to analyze labels. Make sure the FastAPI backend is running at http://127.0.0.1:8000."
      );
    } finally {
      setLoading(false);
    }
  }

  function downloadJsonReport() {
    const blob = new Blob([JSON.stringify(results, null, 2)], {
      type: "application/json"
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "label-verification-report.json";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen">
      <header className="bg-slate-900 text-white">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <h1 className="text-3xl font-bold">AI-Powered Alcohol Label Verification</h1>
          <p className="text-slate-300 mt-2">
            OCR-based prototype for comparing alcohol label artwork against application data.
          </p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8">
        <form onSubmit={analyzeLabels} className="grid lg:grid-cols-2 gap-6">
          <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h2 className="text-xl font-semibold mb-4">Application Information</h2>

            <label className="block mb-4">
              <span className="text-sm font-medium text-slate-700">Brand Name</span>
              <input
                name="brand_name"
                value={form.brand_name}
                onChange={updateForm}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                required
              />
            </label>

            <label className="block mb-4">
              <span className="text-sm font-medium text-slate-700">Class/Type</span>
              <input
                name="class_type"
                value={form.class_type}
                onChange={updateForm}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                required
              />
            </label>

            <label className="block mb-4">
              <span className="text-sm font-medium text-slate-700">Alcohol Content</span>
              <input
                name="alcohol_content"
                value={form.alcohol_content}
                onChange={updateForm}
                placeholder="45% or 90 Proof"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                required
              />
            </label>

            <label className="block mb-4">
              <span className="text-sm font-medium text-slate-700">Net Contents</span>
              <input
                name="net_contents"
                value={form.net_contents}
                onChange={updateForm}
                placeholder="750 mL"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                required
              />
            </label>
          </section>

          <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h2 className="text-xl font-semibold mb-4">Upload Label Artwork</h2>

            <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center">
              <Upload className="w-10 h-10 mx-auto text-slate-500 mb-3" />
              <p className="font-medium">Upload one or more label images</p>
              <p className="text-sm text-slate-500 mb-4">
                PNG, JPG, or JPEG files are recommended for this prototype.
              </p>
              <input
                type="file"
                accept="image/png,image/jpeg,image/jpg"
                multiple
                onChange={handleFileChange}
                className="block mx-auto text-sm"
              />
            </div>

            {files.length > 0 && (
              <div className="mt-4">
                <p className="text-sm font-medium text-slate-700 mb-2">
                  Selected files:
                </p>
                <ul className="text-sm text-slate-600 list-disc ml-5">
                  {files.map((file) => (
                    <li key={file.name}>{file.name}</li>
                  ))}
                </ul>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="mt-6 w-full bg-slate-900 text-white rounded-lg px-4 py-3 font-semibold hover:bg-slate-800 disabled:opacity-60"
            >
              {loading ? "Analyzing..." : "Analyze Label(s)"}
            </button>

            {error && (
              <div className="mt-4 bg-red-50 border border-red-200 text-red-800 rounded-lg p-3">
                {error}
              </div>
            )}
          </section>
        </form>

        {results.length > 0 && (
          <section className="mt-8 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
              <div>
                <h2 className="text-xl font-semibold">Verification Results</h2>
                <p className="text-slate-500 text-sm">
                  Review flagged fields before making a final compliance decision.
                </p>
              </div>
              <button
                onClick={downloadJsonReport}
                className="bg-slate-100 border border-slate-300 rounded-lg px-4 py-2 text-sm font-medium hover:bg-slate-200"
              >
                Download JSON Report
              </button>
            </div>

            <div className="space-y-6">
              {results.map((result, index) => (
                <div key={`${result.file_name}-${index}`} className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="bg-slate-50 px-5 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-slate-600" />
                        <h3 className="font-semibold">{result.file_name}</h3>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
                        <Clock className="w-4 h-4" />
                        {result.processing_time_ms} ms
                      </div>
                    </div>

                    <div className={`inline-flex items-center gap-2 border rounded-full px-3 py-1 text-sm font-semibold ${statusStyles(result.overall_status)}`}>
                      <StatusIcon status={result.overall_status} />
                      {prettyStatus(result.overall_status)}
                    </div>
                  </div>

                  {result.error ? (
                    <div className="p-5 text-red-700">{result.error}</div>
                  ) : (
                    <>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="bg-white border-b">
                              <th className="text-left p-3">Field</th>
                              <th className="text-left p-3">Application Value</th>
                              <th className="text-left p-3">Label Value</th>
                              <th className="text-left p-3">Status</th>
                              <th className="text-left p-3">Confidence</th>
                              <th className="text-left p-3">Notes</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.fields.map((field) => (
                              <tr key={field.field} className="border-b last:border-b-0">
                                <td className="p-3 font-medium">{field.field}</td>
                                <td className="p-3">{field.application_value}</td>
                                <td className="p-3">{field.label_value}</td>
                                <td className="p-3">
                                  <span className={`inline-flex border rounded-full px-2 py-1 text-xs font-semibold ${statusStyles(field.status)}`}>
                                    {prettyStatus(field.status)}
                                  </span>
                                </td>
                                <td className="p-3">{field.confidence}</td>
                                <td className="p-3 text-slate-600">{field.notes}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      <details className="p-5 bg-slate-50">
                        <summary className="cursor-pointer font-medium text-slate-700">
                          View extracted OCR text
                        </summary>
                        <pre className="mt-3 whitespace-pre-wrap text-xs bg-white border rounded-lg p-3 text-slate-700">
                          {result.ocr_text || "No text detected."}
                        </pre>
                      </details>
                    </>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
